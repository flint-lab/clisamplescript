"""Configuration management for FlintCLI, including secure storage of Nexus Access Token (NAT)."""

import os
import json
import time
import jwt
import requests
from cryptography.fernet import Fernet
from pathlib import Path

FLINT_DIR = os.path.expanduser("~/.flintcli")
KEY_PATH = os.path.join(FLINT_DIR, "key")
TOKEN_PATH = os.path.join(FLINT_DIR, "token.enc")
META_PATH = os.path.join(FLINT_DIR, "token_meta.json")
SESSION_DIR = os.path.expanduser("~/.flintcli/sessions")
GMSAAS_API_TOKEN="71ch932gwf6pj5m7pb31784cz01novkvel0qyerc9eds0u2m04bjkdzu47z0ir0gyzjfvl138l6oy866bv4tn0abevz2u3kuxajpl8y0codhny0v2akofs6bgq6q627fts6bp07ccsdpudunlxfhfppj2xfdgpjvt4dv6ewg4iphdzcjnnt7hsppsdc2rm1qyc3fyv9irz091afr48wjcr7eg6qeb40dt2mqiayo80rpefojahm321p1sgwycmrc"

# --------------------------------------------------------------------
# PREPROD CONFIGURATION
# --------------------------------------------------------------------

# API_HEALTH_URL = "https://api.flintlab.io/health"
# API_BASE_URL = "https://preprod.flintlab.io/route/vzg_03/v1/dms"
# VDS_BASE_URL = "https://preprod.flintlab.io/route/vzg_03/v1/vds"
# WS_GATEWAY_URL = "wss://preprod.flintlab.io/route/"
# OLD_HOST = "192.168.0.103:8000"
# NEW_HOST = "preprod.flintlab.io/stream"

# --------------------------------------------------------------------
# STAGING CONFIGURATION
# --------------------------------------------------------------------

API_HEALTH_URL = "https://api.flintlab.io/staging/health"
API_BASE_URL = "https://staging.flintlab.io/route/vzg_02/v1/dms"
VDS_BASE_URL = "https://staging.flintlab.io/route/vzg_02/v1/vds"
WS_GATEWAY_URL = "wss://staging.flintlab.io/route/"
OLD_HOST = "192.168.0.102:8000"
NEW_HOST = "staging.flintlab.io/stream"

# --------------------------------------------------------------------
# DEVELOPMENT CONFIGURATION
# --------------------------------------------------------------------

# API_HEALTH_URL = "https://api.flintlab.io/development/health"
# API_BASE_URL = "https://development.flintlab.io/route/vzg_01/v1/dms"
# VDS_BASE_URL = "https://development.flintlab.io/route/vzg_01/v1/vds"
# WS_GATEWAY_URL = "wss://development.flintlab.io/route/"
# OLD_HOST = "192.168.0.101:8000"
# NEW_HOST = "development.flintlab.io/stream"

def _ensure_flint_dir():
    os.makedirs(FLINT_DIR, exist_ok=True)


def _get_or_create_key():
    _ensure_flint_dir()
    if not os.path.exists(KEY_PATH):
        key = Fernet.generate_key()
        with open(KEY_PATH, "wb") as f:
            f.write(key)
    else:
        with open(KEY_PATH, "rb") as f:
            key = f.read()
    return Fernet(key)


def store_nat(nat: str):
    """Encrypts and stores NAT + decoded metadata."""
    fernet = _get_or_create_key()
    encrypted = fernet.encrypt(nat.encode())
    with open(TOKEN_PATH, "wb") as f:
        f.write(encrypted)

    try:
        decoded = jwt.decode(nat, options={"verify_signature": False})
        exp = decoded.get("exp")
        iat = decoded.get("iat")
        sub = decoded.get("sub")
    except Exception:
        decoded, exp, iat, sub = {}, None, None, None

    meta = {
        "stored_at": time.time(),
        "sub": sub,
    }
    with open(META_PATH, "w") as f:
        json.dump(meta, f)


def get_stored_nat():
    """Return decrypted NAT if valid; else None."""
    if not os.path.exists(TOKEN_PATH):
        return None

    if not is_nat_valid_local():
        delete_nat()
        return None

    fernet = _get_or_create_key()
    with open(TOKEN_PATH, "rb") as f:
        enc = f.read()
    return fernet.decrypt(enc).decode()


def is_nat_valid_local():
    """Check local expiry & 24-hour validity."""
    if not os.path.exists(META_PATH):
        return False
    with open(META_PATH, "r") as f:
        meta = json.load(f)
    stored_at = meta.get("stored_at")

    now = time.time()
    if stored_at and now - stored_at > 24 * 3600:
        return False
    return True


def verify_nat_with_server(token: str) -> tuple[bool, str]:
    """
    Verifies the NAT (Nexus Access Token) with the server.
    Ping API to check token validity and handle gateway/network errors gracefully.

    Returns:
        (is_valid, reason)
        - is_valid: bool → True if token is valid.
        - reason: str → "ok", "invalid_token", "gateway_timeout", "network_error", etc.
    """
    # --- Step 1: Local expiry check ---
    try:
        decoded = jwt.decode(token, options={"verify_signature": False})
        exp = decoded.get("exp")
        if exp and exp < time.time():
            return False, "token_expired"
    except Exception:
        return False, "invalid_token"

    # --- Step 2: Server check (existing logic) ---
    try:
        resp = requests.get(API_HEALTH_URL, headers={"Authorization": f"Bearer {token}"}, timeout=15)

        if resp.status_code == 200:
            data = resp.json()
            return data.get("status") == "ok", "ok"
        elif resp.status_code in (401, 403):
            return False, "invalid_token"
        elif resp.status_code == 504:
            return False, "gateway_timeout"
        else:
            return False, f"server_error_{resp.status_code}"

    except requests.exceptions.Timeout:
        return False, "request_timeout"
    except requests.exceptions.ConnectionError:
        return False, "network_error"
    except Exception as e:
        return False, f"unexpected_error: {str(e)}"


def delete_nat():
    for path in [TOKEN_PATH, META_PATH]:
        if os.path.exists(path):
            os.remove(path)
