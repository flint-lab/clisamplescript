"""Version control commands for FlintCLI."""

import os
import re
import subprocess
import click
from importlib.metadata import version as pkg_version
from packaging import version as v


# Default location to look for new wheel files
DOWNLOADS_DIR = os.path.expanduser("~/Downloads")


# --------------------------------------------------------------------
# HELPER FUNCTIONS
# --------------------------------------------------------------------

def install_with_pipx(whl_path: str):
    """Install or update FlintCLI using pipx."""
    click.echo(f"\nInstalling from {whl_path} via pipx...")
    try:
        subprocess.run(["pipx", "install", "--force", whl_path], check=True)
        click.echo("FlintCLI successfully updated.\n")
    except subprocess.CalledProcessError as e:
        click.echo(f"Installation failed: {e}")


def list_available_versions(download_dir: str):
    """Return sorted list of available FlintCLI wheel versions in Downloads."""
    whl_pattern = r"flintcli-(\d+\.\d+\.\d+)-py3-none-any\.whl"
    if not os.path.isdir(download_dir):
        click.echo(f"Downloads folder not found: {download_dir}")
        return []

    versions = []
    for f in os.listdir(download_dir):
        match = re.match(whl_pattern, f)
        if match:
            versions.append((match.group(1), os.path.join(download_dir, f)))

    versions.sort(key=lambda x: v.parse(x[0]))
    return versions


# --------------------------------------------------------------------
# MAIN COMMAND
# --------------------------------------------------------------------

@click.command(
    "version",
    short_help="Show CLI version and manage upgrades/downgrades.",
)
@click.option(
    "--upgrade",
    "upgrade_path",
    type=click.Path(exists=True),
    help="Path to a .whl file to manually upgrade FlintCLI."
)
@click.option(
    "--downgrade",
    "downgrade_path",
    type=click.Path(exists=True),
    help="Path to a .whl file to manually downgrade FlintCLI."
)
def version_cmd(upgrade_path, downgrade_path):
    """
    Use 'flintcli version' to check current version and manage upgrades/downgrades.
    """
    # Step 1: Show current version
    current_version = pkg_version("flintcli")
    click.echo(f"Current FlintCLI version: {current_version}")

    # Step 2: Handle manual upgrade/downgrade
    if upgrade_path:
        install_with_pipx(upgrade_path)
        return

    if downgrade_path:
        install_with_pipx(downgrade_path)
        return

    # Step 3: Auto check Downloads folder
    available_versions = list_available_versions(DOWNLOADS_DIR)
    if not available_versions:
        click.echo(f"No FlintCLI .whl files found in {DOWNLOADS_DIR}")
        return

    latest_ver, latest_path = available_versions[-1]
    if v.parse(latest_ver) > v.parse(current_version):
        click.echo(f"New version available: {latest_ver}")
        choice = input(f"Would you like to upgrade to {latest_ver}? [Y/N]: ").strip().lower()
        if choice == "y":
            install_with_pipx(latest_path)
        else:
            click.echo("Upgrade skipped.")
    else:
        click.echo(f"FlintCLI is up to date ({current_version}).")



