#!/usr/bin/env python3
"""
ADB WebSocket Client Proxy
Listens locally (default 127.0.0.1:25890) for an ADB client and tunnels the binary
ADB traffic over a WebSocket to the gateway (Kong) at /adb/devices/{device_id}.
"""
import argparse
import asyncio
import logging
import os
import signal
import ssl
from typing import Dict, Optional

import websockets

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("adb-ws-client")


class ClientConfig:
    def __init__(self, gateway: str, device: str, listen_host: str, listen_port: int,
                 keepalive: int, header: Optional[str], insecure_tls: bool):
        self.gateway = gateway.rstrip("/")
        self.device = device
        self.listen_host = listen_host
        self.listen_port = listen_port
        self.keepalive = keepalive
        self.header = header
        self.insecure_tls = insecure_tls

    @property
    def ws_url(self) -> str:
        return f"{self.gateway}/adb/devices/{self.device}"

    def ssl_context(self) -> Optional[ssl.SSLContext]:
        if self.ws_url.startswith("wss://"):
            ctx = ssl.create_default_context()
            if self.insecure_tls:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            return ctx
        return None

    def headers(self) -> Dict[str, str]:
        if self.header:
            try:
                k, v = self.header.split(":", 1)
                return {k.strip(): v.strip()}
            except ValueError:
                logger.warning("--header must be in 'Key: Value' format; ignoring")
        return {}


async def tunnel_once(local_reader: asyncio.StreamReader,
                      local_writer: asyncio.StreamWriter,
                      cfg: ClientConfig) -> None:
    peer = local_writer.get_extra_info("peername")
    logger.info("Local TCP connected from %s; dialing WS %s", peer, cfg.ws_url)

    try:
        async with websockets.connect(
            cfg.ws_url,
            ping_interval=cfg.keepalive,
            max_size=None,
            additional_headers=cfg.headers(),
            ssl=cfg.ssl_context(),
        ) as ws:
            logger.info("WS connected to %s", cfg.ws_url)

            async def tcp_to_ws():
                try:
                    while True:
                        data = await local_reader.read(65536)
                        if not data:
                            # TCP closed -> send a normal WS close so the server sees 1000 (not 1006)
                            try:
                                await ws.close(code=1000, reason="tcp_closed")
                            except Exception:
                                pass
                            break

                        # ADB data MUST be binary frames
                        await ws.send(data)  # websockets sends binary automatically for bytes
                except Exception as e:
                    logger.error("tcp_to_ws error: %s", e)
                    try:
                        await ws.close()
                    except Exception:
                        pass

            async def ws_to_tcp():
                try:
                    async for message in ws:
                        if isinstance(message, (bytes, bytearray)):
                            # Optional: first-frame hex peek for diagnostics
                            if not hasattr(ws, "_adb_peeked"):
                                logger.info("WS→TCP first %d bytes: %s",
                                            min(24, len(message)),
                                            message[:24].hex(" "))
                                ws._adb_peeked = True
                            local_writer.write(message)
                            await local_writer.drain()
                        else:
                            # We only accept binary for ADB
                            logger.error("Received non-binary WS frame; closing (opcode=text)")
                            await ws.close(code=1003, reason="binary_only")
                            break
                except Exception as e:
                    logger.error("ws_to_tcp error: %s", e)


            t1 = asyncio.create_task(tcp_to_ws())
            t2 = asyncio.create_task(ws_to_tcp())
            done, pending = await asyncio.wait({t1, t2}, return_when=asyncio.FIRST_COMPLETED)
            for t in pending:
                t.cancel()
    except Exception as e:
        logger.error("WS connect/send failed: %s", e)
    finally:
        try:
            local_writer.close()
            await local_writer.wait_closed()
        except Exception:
            pass
        logger.info("Local TCP closed for %s", peer)


async def run_server(cfg: ClientConfig) -> None:
    server = await asyncio.start_server(
        lambda r, w: tunnel_once(r, w, cfg),
        host=cfg.listen_host,
        port=cfg.listen_port,
        start_serving=True,
    )

    sockets = ", ".join(str(s.getsockname()) for s in server.sockets or [])
    logger.info("ADB local proxy listening on %s (device=%s, keepalive=%ss)", sockets, cfg.device, cfg.keepalive)

    async with server:
        await server.serve_forever()


def parse_args() -> ClientConfig:
    p = argparse.ArgumentParser(description="ADB TCP<->WebSocket local proxy")
    p.add_argument("--server", required=True, help="Gateway base URL, e.g. ws://kong:8701 or wss://gw.example.com")
    p.add_argument("--device", required=True, help="Device ID (path component)")
    p.add_argument("--listen", default="127.0.0.1:25890", help="Local listen host:port (default 127.0.0.1:25890)")
    p.add_argument("--keepalive", type=int, default=25, help="WS ping interval seconds (default 25)")
    p.add_argument("--header", help="Extra header once, e.g. 'Authorization: Bearer <token>'")
    p.add_argument("--insecure", action="store_true", help="Disable TLS verification for wss://")
    args = p.parse_args()

    host, port_s = args.listen.rsplit(":", 1)
    return ClientConfig(
        gateway=args.server,
        device=args.device,
        listen_host=host,
        listen_port=int(port_s),
        keepalive=args.keepalive,
        header=args.header,
        insecure_tls=args.insecure,
    )


def main():
    try:
        import uvloop  # type: ignore
        uvloop.install()
    except Exception:
        pass

    cfg = parse_args()
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    asyncio.run(run_server(cfg))


if __name__ == "__main__":
    main()
