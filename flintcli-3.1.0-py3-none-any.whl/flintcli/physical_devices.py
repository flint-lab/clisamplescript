"""Commands for device management: list, bind, stream, deallocate."""

import click
import requests
from tabulate import tabulate
from flintcli.config import get_stored_nat, META_PATH , API_BASE_URL, SESSION_DIR , WS_GATEWAY_URL , OLD_HOST , NEW_HOST
from flintcli.utils import require_auth, get_free_port, launch_electron
import signal
import platform
import os
import json
from pathlib import Path
import socket
import sys
import jwt
import subprocess
import time
"""Helper functions for ADB key management and connection."""


def adb_connect_with_retry(host: str, port: int, retries: int = 5, delay: float = 1.0):
    """
    Try 'adb connect' multiple times with exponential backoff.
    Returns (success: bool, message: str).
    """

    adb_cmd = ["adb", "connect", f"{host}:{port}"]
    output = ""

    for attempt in range(1, retries + 1):
        try:
            result = subprocess.run(adb_cmd, capture_output=True, text=True, check=True)
            stdout = result.stdout.strip()
            stderr = result.stderr.strip()

            if "already connected" in stdout.lower():
                print("[INFO] ADB authorisation is required. Please use 'flintcli stream -i <device_id>' to start streaming and authorise the connection.")
                return True, stdout
            elif "connected to" in stdout.lower():
                print("[INFO] ADB connection established successfully.")
                return True, stdout

            if stderr:
                print(f"[DEBUG] adb stderr: {stderr}")
        except subprocess.CalledProcessError as e:
            output = e.stderr or e.stdout or str(e)
            print(f"[WARN] adb connect failed (attempt {attempt}): {output.strip()}")
        except FileNotFoundError:
            return False, "[ERROR] adb not found. Please install Android platform-tools."

        if attempt < retries:
            time.sleep(delay * attempt)

    print("[ERROR]  adb connect failed after all retries.")
    return False, f"adb connect failed after {retries} attempts. Last error:\n{output.strip()}"

def deallocate_physical_device(device_id: str):
    """Deallocate a device, stop proxy, and close viewer."""

    session_file = os.path.join(SESSION_DIR, f"{device_id}.json")
    if not os.path.exists(session_file):
        # Try API call to check if device was already deallocated
        nat = get_stored_nat()
        url = f"{API_BASE_URL}/flintlab/api/v1/device/ops/deallocate/{device_id}"
        headers = {"Authorization": f"Bearer {nat}", "Content-Type": "application/json"}
        payload = {"user_id": "Flintcli-user"}
        
        try:
            res = requests.post(url, headers=headers, json=payload, timeout=10)
            if res.status_code == 404:
                try:
                    body = res.json()
                    detail = body.get("detail", "Already deallocated for this session due to timeout.")
                except (ValueError, KeyError):
                    detail = "Already deallocated for this session due to timeout."
                click.secho(f"[i] {detail}", fg="yellow")
            else:
                click.secho(f"[i] No active session found for device {device_id}. Device may have already been deallocated due to timeout or was never allocated.", fg="yellow")
        except requests.RequestException:
            click.secho(f"[i] No active session found for device {device_id}. Device may have already been deallocated due to timeout or was never allocated.", fg="yellow")
        return

    # Load session details
    with open(session_file, "r") as f:
        session = json.load(f)

    stored_auth0_id = session.get("auth0_id")
    nat = get_stored_nat()
    current_auth0_id = jwt.decode(nat, options={"verify_signature": False}).get("sub")

    if stored_auth0_id != current_auth0_id:
        click.secho("[!] You cannot deallocate this device. It was allocated under a different user identity.", fg="red")
        return

    url = f"{API_BASE_URL}/flintlab/api/v1/device/ops/deallocate/{device_id}"
    headers = {"Authorization": f"Bearer {nat}", "Content-Type": "application/json"}
    payload = {"user_id": session.get("user_id", "Flintcli-user")}

    # 1️⃣ Kill proxy process
    proxy_pid = session.get("proxy_pid")
    if proxy_pid:
        try:
            if platform.system().lower() == "windows":
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(proxy_pid)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=10,
                    check=False
                )
            else:
                os.kill(proxy_pid, 9)
        except ProcessLookupError:
            click.secho("[i] Proxy process already exited.", fg="yellow")
        except Exception as e:
            click.secho(f"[!] Failed to stop proxy {proxy_pid}: {e}", fg="red")

    # 2️⃣ Kill viewer window if open
    viewer_pid = session.get("viewer_pid")
    if viewer_pid:
        try:
            if platform.system().lower() == "windows":
                subprocess.call(
                    ["taskkill", "/F", "/T", "/PID", str(viewer_pid)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS,
                )
            else:
                pgid = os.getpgid(viewer_pid)
                os.killpg(pgid, signal.SIGKILL)
            click.secho("[✓] Closed viewer window", fg="yellow")
        except ProcessLookupError:
            click.secho("[i] Viewer already closed.", fg="blue")
        except Exception as e:
            click.secho(f"[!] Failed to close viewer (PID={viewer_pid}): {e}", fg="red")

    # 2.5️⃣ Disconnect ADB if serial exists (MINIMAL ADDITION)
    adb_serial = session.get("adb_serial")
    if adb_serial:
        try:
            subprocess.run(
                ["adb", "disconnect", adb_serial],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
                check=False
            )
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            pass  # Ignore errors

    # 3️⃣ Call API to deallocate device
    try:
        res = requests.post(url, headers=headers, json=payload, timeout=10)
        if res.ok:
            click.secho(f"[✓] Device {session.get('name')} deallocated successfully.", fg="green")
            try:
                os.remove(session_file)
            except OSError as e:
                click.secho(f"[!] Failed to delete session file {session_file}: {e}", fg="red")
        elif res.status_code == 404:
            try:
                body = res.json()
                detail = body.get("detail", "Already deallocated for this session due to timeout.")
            except (ValueError, KeyError):
                detail = "Already deallocated for this session due to timeout."
            click.secho(f"[i] {detail}", fg="yellow")
            try:
                os.remove(session_file)
            except OSError:
                pass
        else:
            click.secho(
                f"[!] API deallocation failed: {res.status_code} {res.reason} for url: {res.url}",
                fg="red",
            )
    except requests.RequestException as e:
        click.secho(f"[!] API deallocation failed: {e}", fg="red")

def rewrite_stream_url(stream_url: str, old_host: str, new_host: str, token: str = None) -> str:
    """
    Rewrites the given stream URL to use a new host and appends a token.
    
    Args:
        stream_url (str): The original stream URL returned by the API.
        old_host (str): The old host to be replaced (e.g., '192.168.0.102:8000').
        new_host (str): The new host to replace with (e.g., 'preprod.flintlab.io/stream').
        token (str, optional): Token to append to the URL. Default is None.

    Returns:
        str: The modified stream URL.
    """
    if not stream_url:
        raise ValueError("stream_url cannot be empty")

    # Replace the base host in the stream URL
    modified_url = stream_url.replace(old_host, new_host)

    # Replace the encoded websocket parameter if present
    encoded_old = f"ws=wss%3A%2F%2F{old_host.replace(':', '%3A')}"
    encoded_new = f"ws=wss%3A%2F%2F{new_host.replace(':', '%3A')}"
    modified_url = modified_url.replace(encoded_old, encoded_new)

    modified_url += f"&token={token}"

    return modified_url

def list_physical_devices():
    nat = get_stored_nat()
    url = f"{API_BASE_URL}/flintlab/api/v1/device/list/"
    response = requests.get(url, headers={"Authorization": f"Bearer {nat}","X-Tenant-Id": jwt.decode(nat, options={"verify_signature": False}).get("tenant_id","default")})

    if response.status_code != 200:
        click.echo(f"Error: {response.status_code} - {response.text}")
        return

    devices = response.json()

    devices = [d for d in devices if d.get("Availability") in ["available", "busy"]]

    if not devices:
        click.echo("No matching physical devices found.")
        return

    table_data = [
        [d["device_id"], d["name"], d["os"], d["os_version"], d["Availability"]]
        for d in devices
    ]

    headers = ["Device ID", "Name", "OS", "Version", "Availability"]
    click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))

def bind_physical_device(device_id, duration_minutes, port):
    """Use 'flintcli bind -i <device_id>' to allocate a device."""
    nat = get_stored_nat()
    decoded = jwt.decode(nat, options={"verify_signature": False})
    auth0_id = decoded.get("sub", "unknown-user")   

    user_id = "Flintcli-user"
    if os.path.exists(META_PATH):
        try:
            with open(META_PATH, "r") as f:
                meta = json.load(f)
                user_id = meta.get("sub", user_id)
        except Exception as e:
            click.secho(f"[!] Failed to read user metadata: {e}", fg="black")

    url = f"{API_BASE_URL}/flintlab/api/v1/device/ops/allocate/{device_id}?enable_cli=true"
    headers = {"Authorization": f"Bearer {nat}", "Content-Type": "application/json", "X-Tenant-Id": jwt.decode(nat, options={"verify_signature": False}).get("tenant_id","default")}
    payload = {"user_id": user_id, "time_requested": duration_minutes}

    try:
        try:
            listen_port = get_free_port(port=port)
        except ValueError as e:
            click.secho(f"[!] Invalid port number, port should be between 1 and 65536", fg="red")
            return
        res = requests.post(url, headers=headers, json=payload)
        res.raise_for_status()
        data = res.json()

        stream_url = data.get("stream_url")
        if not stream_url:
            click.secho("[!] No stream URL in response. Aborting.", fg="red")
            return

        # 🔹 Dynamically rewrite the stream URL
        old_host = OLD_HOST
        new_host = NEW_HOST
        modified_url = rewrite_stream_url(stream_url, old_host, new_host, token=nat)

        name = data.get("device_details", {}).get("name")

        # 🔹 Pick free port & launch websocket bridge
        # listen_port = get_free_port(port=port)
        listen_host = "127.0.0.1"
        ws_gateway = WS_GATEWAY_URL
        ws_script = os.path.join(os.path.dirname(__file__), "web_socket.py")

        ws_cmd = [
            sys.executable, "-u", ws_script,
            "--server", ws_gateway,
            "--device", device_id,
            "--listen", f"{listen_host}:{listen_port}",
            "--header", f"Authorization: Bearer {nat}",
            "--insecure"
        ]

        proc = subprocess.Popen(
            ws_cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        # 🔹 Save session
        os.makedirs(SESSION_DIR, exist_ok=True)
        session_path = os.path.join(SESSION_DIR, f"{device_id}.json")
        session_data = {
            "device_id": device_id,
            "user_id": user_id,
            "auth0_id": auth0_id,
            "name": name,
            "listen_host": listen_host,
            "listen_port": listen_port,
            "proxy_pid": proc.pid,
            "stream_url": modified_url,
            "allocated_at": int(time.time()),
            "time_requested": duration_minutes,
        }
        with open(session_path, "w") as f:
            json.dump(session_data, f)

        # 🔹 Show success + auto adb connect
        click.secho(f"[✓] Device {name} allocated successfully.", fg="green")

        success, msg = adb_connect_with_retry(listen_host, listen_port)
        if success:
            click.secho(msg, fg="green")
            session_data["adb_serial"] = f"{listen_host}:{listen_port}"
            with open(session_path, "w") as f:
                json.dump(session_data, f)
            
            # 🔹 Spawn detached auto-cleanup process (MINIMAL ADDITION)
            try:
                seconds = max(60, int(duration_minutes) * 60)
                code = (
                    "import time, subprocess, platform; "
                    f"time.sleep({seconds}); "
                    "creationflags = subprocess.CREATE_NO_WINDOW if platform.system().lower() == 'windows' else 0; "
                    "subprocess.run(['flintcli', 'deallocate', '--physical-device', '-i', "
                    f"'{device_id}'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=creationflags)"
                )
                
                if platform.system().lower() == "windows":
                    python_exe = sys.executable
                    pythonw_exe = python_exe.replace("python.exe", "pythonw.exe")

                    subprocess.Popen(
                        [pythonw_exe, "-c", code],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        stdin=subprocess.DEVNULL,
                        creationflags=(
                            subprocess.CREATE_NEW_PROCESS_GROUP
                            | subprocess.DETACHED_PROCESS
                            | subprocess.CREATE_NO_WINDOW
                        ),
                    )
                else:
                    subprocess.Popen(
                        [sys.executable, "-c", code],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        stdin=subprocess.DEVNULL,
                        preexec_fn=os.setsid,
                        close_fds=True,
                    )
            except Exception:
                pass  # Ignore errors spawning cleanup process
        else:
            click.secho(msg, fg="red")
            deallocate_physical_device(device_id)

    except requests.RequestException as e:
        click.secho(f"[!] Allocation failed: {e}", fg="red")


def stream_physical_device(device_id):
  """Use 'flintcli stream -i <device_id>' to stream the device."""

  session_path = os.path.join(SESSION_DIR, f"{device_id}.json")

  if not os.path.exists(session_path):
    click.secho(f"[!] No session found for {device_id}. Use `flintcli bind` first.", fg="red")
    return

  with open(session_path, "r") as f:
    session = json.load(f)

  stream_url = session.get("stream_url")
  user_id = session.get("user_id")
  device_ip = session.get("device_ip")
  name = session.get("name")
  if not stream_url or not user_id:
    click.secho("[!] Incomplete session data. Please re-bind the device.", fg="red")
    return

  click.secho("[✓] Launching custom Electron viewer...", fg="green")
  try:
      launch_electron(stream_url, session_path)
  except Exception as e:
      click.secho(f"[!] Could not launch Electron: {str(e)}", fg="red")

