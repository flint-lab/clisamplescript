"""Main CLI entry point for FlintCLI."""

import contextlib
import io

import click

from flintcli.auth import auth_command, status_command, logout_command
from flintcli.commands import list, bind_device, stream_device, deallocate_device
from flintcli.electron_setup import install_electron_if_needed
from flintcli.emulator_service import bootstrap_emulator_dependencies
from flintcli.version_control import version_cmd
CONTEXT_SETTINGS = {
    "help_option_names": ["-h", "--help"],
    "max_content_width": 120,
}

CLI_HEADER = "Welcome to FlintCLI!"

CLI_EXAMPLES = [
    "flintcli auth --nat <your_nat_token>",
    "flintcli list --physical-devices",
    "flintcli list --emulator",
    "flintcli bind --physical-device -i <Device_ID> --duration_minutes 60",
    "flintcli bind --emulator -i <Recipe_ID> --duration_minutes 30",
    "flintcli stream --emulator -i <Instance_ID>",
    "flintcli stream --physical-device -i <Device_ID>"
    "flintcli deallocate --emulator -i <Insatnce_ID>",
    "flintcli version",
]


class FlintCLIGroup(click.Group):
    """Custom Click group for structured FlintCLI help output."""

    def format_help(self, ctx, formatter) -> None:
        """Render help with overview, options, commands, and examples."""
        # Usage line
        self.format_usage(ctx, formatter)
        formatter.write_paragraph()

        # Overview text (no explicit "Header" label, matches Click style)
        self.format_help_text(ctx, formatter)
        formatter.write_paragraph()

        # Commands section (auto-generated from registered commands)
        with formatter.section("Commands"):
            rows = [
                ("-h",  "shows the  helpful commands for flintcli ."),
            ]
            for name in self.list_commands(ctx):
                command = self.get_command(ctx, name)
                if command is None or command.hidden:
                    continue
                short_help = command.get_short_help_str()
                rows.append((name, short_help))

            if rows:
                formatter.write_dl(rows)

        # Examples section
        if CLI_EXAMPLES:
            with formatter.section("Examples"):
                for example in CLI_EXAMPLES:
                    formatter.write_text(example)

        # Duration limits section
        with formatter.section("Duration limits"):
            formatter.write_text("minimum allocation minutes = 3")
            formatter.write_text("maximum allocation minutes = 720")


@click.group(
    cls=FlintCLIGroup,
    context_settings=CONTEXT_SETTINGS,
    help=CLI_HEADER,
)
def cli():
    """Root command for FlintCLI."""
    try:
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            install_electron_if_needed()
    except Exception as e:
        click.secho(f"[!] Electron Setup failed: {e}", fg="red")
    try:
        bootstrap_emulator_dependencies()
    except Exception:
        pass

cli.add_command(auth_command)
cli.add_command(list)
cli.add_command(bind_device)
cli.add_command(stream_device)
cli.add_command(status_command)
cli.add_command(logout_command)
cli.add_command(deallocate_device)
cli.add_command(version_cmd)

if __name__ == "__main__":
    cli()