"""Commands for user authentication using Nexus Access Token (NAT)."""

import click
from getpass import GetPassWarning
from flintcli.config import  store_nat, verify_nat_with_server, get_stored_nat, delete_nat, META_PATH, SESSION_DIR
import os
import time
import json
import sys
import psutil


@click.command(
    "auth",
    short_help="Authenticate using a Nexus Access Token (NAT).",
)
@click.option("--nat", help="Nexus Access Token for FlintAPI")
def auth_command(nat):
    """Use 'flintcli auth' to authenticate with your Nexus Access Token (NAT)."""
    # Handle missing NAT
    if not nat:
        # Detect non-interactive environment (like pytest)
        if not sys.stdin.isatty():
            click.secho("[x] NAT cannot be empty. Please provide via --nat flag.", fg="red")
            sys.exit(1)

        # Interactive mode → prompt user
        while not nat:
            click.secho("[x] NAT cannot be empty. Please try again.", fg="red")
            nat = click.prompt("Enter your Nexus Access Token (NAT)", hide_input=True).strip()

    click.secho("[i] Verifying NAT", fg="cyan")
    is_valid, reason = verify_nat_with_server(nat)

    if is_valid:
        store_nat(nat)
        click.secho("[✓] Authentication successful! Token stored for 24 hours.", fg="bright_green")
    else:
        if reason == "invalid_token":
            click.secho("[x] Invalid or revoked NAT. Please check your token.", fg="red")
        elif reason in ("gateway_timeout", "network_error", "request_timeout"):
            click.secho(f"[x] Network issue ({reason}). Please check your connection and try again.", fg="yellow")
        elif reason == "token_expired":
            click.secho("[x] Your NAT has expired. Please provide a valid NAT.", fg="red")
        else:
            click.secho(f"[x] Authentication failed ({reason}).", fg="red")
        sys.exit(1)


@click.command(
    "status",
    short_help="Show current authentication status.",
)
def status_command():
    """Use 'flintcli status' to check authentication status."""
    nat = get_stored_nat()
    if not nat:
        click.secho("[x] No valid NAT stored. Use 'flintcli auth' to authenticate.", fg="red")
        return

    # Read stored time metadata
    if os.path.exists(META_PATH):
        with open(META_PATH, "r") as f:
            meta = json.load(f)
        stored_at = meta.get("stored_at")
        sub = meta.get("sub")
    else:
        click.secho("[x] No token metadata found. Please re-authenticate.", fg="red")
        return

    # Calculate remaining time out of 24h
    now = time.time()
    elapsed = now - stored_at
    remaining = max(0, 24 * 3600 - elapsed)
    hours_left = remaining / 3600

    if remaining <= 0:
        click.secho("[x] Please Re-authenticate.", fg="red")
        delete_nat()
        return

    # Verify remotely to ensure not revoked
    click.echo("[*] Checking the Nexus Access Token with the server...")
    if verify_nat_with_server(nat):
        click.secho(f"[✓] Token is valid .", fg="green")
        click.secho(f"[i] Time remaining: {hours_left:.1f} hours", fg="yellow")
        
    else:
        click.secho("[x] NAT is revoked or invalid.", fg="red")
        delete_nat()
        return
    
    # List Allocated Devices
    click.secho("\nAllocated Devices:", fg="cyan")

    os.makedirs(SESSION_DIR, exist_ok=True)

    allocated = []
    for file in os.listdir(SESSION_DIR):
        if file.endswith(".json"):
            path = os.path.join(SESSION_DIR, file)
            with open(path, "r") as f:
                session = json.load(f)
                allocated.append(session)

    if not allocated:
        click.secho("[i] No devices allocated.", fg="blue")
        return

    for idx, s in enumerate(allocated, start=1):
        viewer = s.get("viewer_pid")
        device_name = s.get("name")
        device_id = s.get("device_id")
        status = "RUNNING" if viewer and psutil.pid_exists(viewer) else "CLOSED"

        click.echo(f"""
        {idx}. {device_name}
            ID: {device_id}
            Viewer: {status}
        """)


@click.command(
    "logout",
    short_help="Remove the stored NAT and end the session.",
)
def logout_command():
    """Use 'flintcli logout' to remove the stored NAT."""
    if get_stored_nat():
        delete_nat()
        click.secho("[+] Logged out. NAT removed.", fg="yellow")
    else:
        click.secho("[x] No stored NAT to remove.", fg="red")
