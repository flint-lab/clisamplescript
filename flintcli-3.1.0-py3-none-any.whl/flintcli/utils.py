"""Utility functions and decorators for FlintCLI."""

import os
import sys
import click
import psutil
import socket
import json
import platform
import subprocess
from contextlib import closing
from pathlib import Path
from typing import Optional
from flintcli.config import get_stored_nat, verify_nat_with_server

def require_auth(func):
    """
    Decorator to ensure a valid and active NAT is present before running the command.
    - Checks if a NAT is stored and not expired (local validation).
    - Verifies the NAT with the Flint API to ensure it’s not revoked.
    - Exits cleanly if authentication fails.
    """
    def wrapper(*args, **kwargs):
        token = get_stored_nat()
        if not token:
            click.secho("You are not authenticated. Run `flintcli auth` first.", fg="red")
            sys.exit(1)

        is_valid, reason = verify_nat_with_server(token)

        if not is_valid:
            if reason == "invalid_token":
                click.secho("Your NAT is invalid or revoked. Please reauthenticate using `flintcli auth`.", fg="red")
            elif reason in ("gateway_timeout", "network_error", "request_timeout"):
                click.secho(f"Network issue ({reason}). Please check your connection and try again.", fg="yellow")
            elif reason == "token_expired":
                click.secho("Your NAT has expired. Please reauthenticate using a valid NAT.", fg="red")
            else:
                click.secho(f"Authentication check failed ({reason}).", fg="red")
            sys.exit(1)


        return func(*args, **kwargs)

    wrapper.__name__ = func.__name__  # keep click help clean
    wrapper.__doc__ = func.__doc__
    return wrapper

def is_port_free(port: int, host: str) -> bool:
    """Check if a TCP port is free on the given host."""
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        try:
            s.bind((host, port))
            return True
        except OSError:
            return False


def get_free_port(port: Optional[int] = None, host: str = "127.0.0.1"):
    """
    Find a free TCP port in a cross-platform way.

    - If `port` is provided, try it first.
    - If unavailable, try the next ports sequentially.
    - If `port` is None, let the OS choose a free port.
    """
    if port is None:
        with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
            s.bind((host, 0))
            chosen = s.getsockname()[1]
            # click.secho(f"[✓] Auto-selected free port {chosen}", fg="yellow")
            return chosen

    if not (0 < port < 65536):
        raise ValueError(f"Invalid port number: {port}")

    for candidate in range(port, 65536):
        sys.stdout.write(f"\r[i] Checking port {candidate}...")
        sys.stdout.flush()

        if is_port_free(candidate, host):
            sys.stdout.write("\r" + " " * 80 + "\r")
            sys.stdout.flush()

            click.secho(f"[✓] Using port {candidate}", fg="green")
            return candidate

        sys.stdout.write("\r" + " " * 80 + "\r")
        sys.stdout.flush()

        click.secho(f"[!] Port {candidate} is unavailable", fg="yellow")

    raise RuntimeError("No free ports available in the remaining port range")

def launch_electron(stream_url: str, session_path: str = None):
    viewer_path = os.path.join(os.path.dirname(__file__), "viewer")
    env = os.environ.copy()

    if platform.system().lower() == "windows":
        # Pass URL via env var so the shell does not truncate it at '&'.
        # Use shell=True so Windows finds npx (npx.cmd); URL is not in the command.
        env["FLINT_STREAM_URL"] = stream_url
        cmd_str = "npx electron --disable-gpu --disable-gpu-compositing --use-angle=swiftshader ."
        process = subprocess.Popen(
            cmd_str,
            cwd=viewer_path,
            env=env,
            shell=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
        )
    else:
        cmd = ["npx", "electron", ".", stream_url]
        process = subprocess.Popen(
            cmd,
            cwd=viewer_path,
            env=env,
            shell=False,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            preexec_fn=os.setsid
        )

    # Save viewer PID if session exists
    if session_path and os.path.exists(session_path):
        with open(session_path, "r") as f:
            session = json.load(f)
        session["viewer_pid"] = process.pid
        with open(session_path, "w") as f:
            json.dump(session, f, indent=2)

def start_local_stream_server(port: int):
    """
    Start a lightweight HTTP server to serve stream.html for emulator streaming.
    Runs in background.
    """
    viewer_path = os.path.join(os.path.dirname(__file__), "viewer")

    if platform.system().lower() == "windows":
        python_exe = sys.executable
        pythonw_exe = python_exe.replace("python.exe", "pythonw.exe")
        cmd = [
            pythonw_exe,
            "-m",
            "http.server",
            str(port),
        ]
    else:
        cmd = [
            sys.executable,
            "-m",
            "http.server",
            str(port),
        ]

    process = subprocess.Popen(
        cmd,
        cwd=viewer_path,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        preexec_fn=os.setsid if platform.system() != "Windows" else None,
        creationflags=(
            subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
        )
        if platform.system() == "Windows"
        else 0,
    )

    return process.pid