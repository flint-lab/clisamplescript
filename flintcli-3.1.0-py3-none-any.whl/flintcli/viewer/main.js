const { app, BrowserWindow } = require('electron');
const path = require('path');



function createWindow() {
  // Windows: Python passes --stream-url <url> so URL is argv[3]. Linux/macOS: URL is argv[2].
  let streamUrl = process.env.FLINT_STREAM_URL;
  if (!streamUrl && process.argv[2] === '--stream-url' && process.argv[3]) {
    streamUrl = process.argv[3];
  } else if (!streamUrl) {
    streamUrl = process.argv[2];
  }

  if (!streamUrl) {
    console.error(" No stream URL provided.");
    app.quit();
    return;
  }

  const win = new BrowserWindow({
    width: 385,
    height: 732,
    minHeight: 732,
    minWidth: 385,
    maxWidth: 448,
    maxHeight: 732,
    title: "Flint Device Stream",
    resizable: true,              
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: false,
      sandbox: false,
      webSecurity: false,
      allowRunningInsecureContent: true,
    }
  });

  win.loadURL(streamUrl).catch(err => {
    console.error("Failed to load URL:", err);
    win.loadURL(`data:text/html,<h2 style="color:red;text-align:center;margin-top:40vh;">Failed to load stream: ${err.message}</h2>`);
  });
}

// Apply flags BEFORE app is ready
if (process.platform === 'linux') {
  app.commandLine.appendSwitch('no-sandbox');
  app.commandLine.appendSwitch('disable-gpu'); // Optional: helps on some Linux VMs
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  app.quit();
});
