import requests
import jwt
import click
import os
import time
import sys
import json
import signal
import platform
import subprocess
import threading
import urllib.parse
from itertools import cycle
from tabulate import tabulate
from datetime import datetime, timedelta, timezone
from flintcli.emulator_service import adb_connect
from flintcli.config import VDS_BASE_URL, get_stored_nat, SESSION_DIR
from flintcli.session import load_session, save_session, cleanup_session
from flintcli.utils import launch_electron, start_local_stream_server, get_free_port

nat = get_stored_nat()
decoded = jwt.decode(nat, options={"verify_signature": False}) if nat else {}
tenant_id = decoded.get("tenant_id", "default")
user_id = decoded.get("sub", "flintcli-user")

def fetch_emulator_status(device_id: str):
    """Fetch device details from VDS (single source of truth)."""
    try:
        resp = requests.get(
            f"{VDS_BASE_URL}/flintlab/api/v1/gm/instances/status",
            headers = {
                "Authorization": f"Bearer {nat}",
                "Content-Type": "application/json",
                "X-Tenant-Id": tenant_id
            },
            params={"instance_id": device_id},
            timeout=10
        )

        if resp.status_code == 404:
            return None

        resp.raise_for_status()
        status = resp.text.strip().strip('"')  
        return status.lower()

    except requests.RequestException as e:
        return None

def get_emulator_recipes():
    """Fetch recipes and optionally filter them."""
    url = f"{VDS_BASE_URL}/flintlab/api/v1/vd/recipes/list?active_only=true"

    response = requests.get(
        url,
        headers={
            "Authorization": f"Bearer {nat}",
            "X-Tenant-Id": tenant_id
        }
    )

    if response.status_code != 200:
        click.echo(f"Error: {response.status_code} - {response.text}")
        return None

    return response.json()

def list_emulator_devices():
    recipes = get_emulator_recipes()

    if not recipes:
        click.echo("No matching emulator recipes found.")
        return

    table_data = []
    for recipe in recipes:
        name = recipe.get("hardware_model", "")

        text_fields = [
            str(recipe.get("name", "") or ""),
            str(recipe.get("os", "") or ""),
            str(recipe.get("description", "") or ""),
        ]
        combined = " ".join(text_fields).lower()
        if "gapps" in combined or "g apps" in combined:
            name = f"{name} with GApps"

        table_data.append(
            [
                recipe["recipe_id"],
                name,
                recipe["os_version"],
                recipe["architecture"],
                recipe["status"],
            ]
        )

    headers = ["Recipe ID", "Name", "Version", "Architecture", "Status"]
    click.echo(tabulate(table_data, headers=headers, tablefmt="grid"))

# ---------- Spinner ----------
spinner_cycle = cycle(["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"])

def run_spinner(stop_event: threading.Event, message: str):
    while not stop_event.is_set():
        sys.stdout.write("\r" + next(spinner_cycle) + " " + message)
        sys.stdout.flush()
        time.sleep(0.1)
    sys.stdout.write("\r\033[K")
    sys.stdout.flush()

# Allocate emulator + bind adb
def allocate_emulator(recipe_uuid: str, duration_minutes: int, port: int | None = None):
        """Start an emulator and bind ADB locally.

        The duration_minutes value is expected to be validated by the CLI layer
        (currently constrained to 3–720 minutes).
        """
        timeout = int(duration_minutes)
        # Start instance via VDS
        url = f"{VDS_BASE_URL}/flintlab/api/v1/vd/devices/devices/start"
        headers = {
            "Authorization": f"Bearer {nat}",
            "Content-Type": "application/json",
            "X-Tenant-Id": tenant_id
        }

        payload = {
            "recipe_uuid": recipe_uuid,
            "tenant_id": tenant_id,
            "user_id": user_id,
            "name": "flintcli-session",
            "timeout_global": timeout,
            "timeout_inactive": timeout
        }

        allocated_at = datetime.now(timezone.utc)
        expires_at = allocated_at + timedelta(minutes=timeout)

        # Start allocation in background thread
        class StartWorker(threading.Thread):
            def __init__(self):
                super().__init__(daemon=True)
                self.response = None
                self.error = None
                self.done = threading.Event()

            def run(self):
                try:
                    res = requests.post(url, headers=headers, json=payload, timeout=180)
                    res.raise_for_status()
                    self.response = res.json()
                except Exception as e:
                    self.error = e
                finally:
                    self.done.set()

        worker = StartWorker()
        worker.start()

        spinner_stop = threading.Event()
        spinner_thread = threading.Thread(
            target=run_spinner,
            args=(spinner_stop, "Allocating emulator instance..."),
            daemon=True
        )
        spinner_thread.start()

        worker.done.wait()
        spinner_stop.set()
        spinner_thread.join()

        if worker.error:
            msg = str(worker.error).lower()

            if "504" in msg or "gateway" in msg or "timeout" in msg:
                click.secho(
                    "Instance creation took longer than expected.\n"
                    "Please try allocating the emulator again.", fg="yellow"
                )
                return None
            else:
                click.secho(f"[!] Emulator start failed, please try allocating the emulator again.", fg="red")
            return None

        data = worker.response or {}
        device_id = data["device_id"]

        if not device_id:
            click.secho("Invalid response from emulator service")
            return
        
        click.secho(f"Emulator Instance id :{device_id}", fg="green")
        click.secho(f"Use the instance id to stream or deallocate the emulator", fg="green")

        #  Bind ADB locally via gmsaas
        spinner_stop = threading.Event()
        spinner_thread = threading.Thread(
            target=run_spinner,
            args=(spinner_stop, "Binding your emulator instance..."),
            daemon=True
        )
        spinner_thread.start()
        try:
            adb_serial = adb_connect(device_id, port)
        except:
            spinner_stop.set()
            spinner_thread.join()
            click.secho(f"[!] ADB binding failed", fg="red")
            return None
        
        spinner_stop.set()
        spinner_thread.join()

        # Show where the emulator is bound locally for ADB
        if adb_serial:
            click.secho(
                f"ADB serial bound at: {adb_serial}",
                fg="green",
            )

        session_data = {
            "device_id": device_id,
            "adb_serial": adb_serial,
            "tenant_id": tenant_id,
            "user_id": user_id,
            "webrtc_url": data.get("webrtc_url"),
            "file_upload_url": data.get("file_upload_url"),
            "allocated_at": allocated_at.isoformat(),
            "timeout_minutes_global_minutes": timeout,
            "expires_at": expires_at.isoformat(),
        }
        save_session(device_id, session_data)
        
        click.secho(f"[✓] Emulator bound successfully", fg="green")

def stream_emulator(device_id: str):
    """
    Stream a running Genymotion emulator using WebRTC via Electron viewer.
    """

    # Validate local session (TTL check)
    session = load_session(device_id)
    if not session:
        click.secho(
            "[!] No active session found.\n"
            "Run: flintcli bind --emulator -i <recipe_id>",
            fg="red"
        )
        return

    status = fetch_emulator_status(device_id)
    if status is None:
        cleanup_session(device_id)
        click.secho(
            "[!] Emulator no longer exists (likely auto-terminated). Allocate again: flintcli bind --emulator <recipe_id>",
            fg="red"
        )
        return

    if session["tenant_id"] != tenant_id or session["user_id"] != user_id:
        click.secho("[!] Emulator was not allocated by current user", fg="red")

    if status != "online":
        click.secho(f"status: {status}")
        click.secho(
            f"[!] Emulator is not running (likely auto-terminated or already deallocated). Please allocate again!",
            fg="red"
        )
        return
    
    webrtc_url = session.get("webrtc_url")
    
    file_upload_url = session.get("file_upload_url")
    if not webrtc_url:
        click.secho("[!] Streaming not available. Re-allocate the emulator.", fg="red")
        return

    try:
        token_res = requests.get(
            f"{VDS_BASE_URL}/flintlab/api/v1/vd/devices/devices/get_token",
            headers={
                "Authorization": f"Bearer {nat}",
                "X-Tenant-Id": tenant_id
            },
            params={"device_id": device_id},
            timeout=10
        )
        token_res.raise_for_status()
        token = token_res.json() 
    except Exception as e:
        click.secho("[!] Failed to stream the emulator", fg="red")
        return

    if not token:
        click.secho("[!] Streaming not available for this emulator", fg="red")
        return
    
    encoded_webrtc = urllib.parse.quote(webrtc_url)
    encoded_token = urllib.parse.quote(token)
    encoded_file_upload_url = urllib.parse.quote(file_upload_url)

    port = get_free_port()
    time.sleep(1)  # brief wait for port binding
    server_pid = start_local_stream_server(port=port)

    # Build streaming URL for Electron
    stream_url = (
        f"http://localhost:{port}/stream.html"
        f"?webrtcAddress={encoded_webrtc}"
        f"&token={encoded_token}"
        f"&fileUploadUrl={encoded_file_upload_url}"
        f"&deviceId={device_id}"
    )
    session["local_server_port"] = port
    session["local_server_pid"] = server_pid
    save_session(device_id, session)
    click.secho("[✓] Launching emulator stream...", fg="green")

    # Launch Electron viewer
    try:
        session_path = os.path.join(SESSION_DIR, f"{device_id}.json")
        launch_electron(stream_url, session_path)
    except Exception as e:
        click.secho("[!] Failed to launch Electron viewer", fg="red")
        

# DEALLOCATE
def deallocate_emulator(device_id: str):
    """ Stop / deallocate emulator instance."""
    status = fetch_emulator_status(device_id)
    if status is None:
        cleanup_session(device_id)
        click.secho(
            "[i] Emulator already deallocated due to timeout or never existed.",
            fg="yellow"
        )
        return

    if status in ("stopped", "disposed", "recycled"):
            click.secho("[i] Emulator already deallocated due to timeout.", fg="yellow")
            cleanup_session(device_id)
            return
    session = load_session(device_id)
    if session:
        if session["tenant_id"] != tenant_id or session["user_id"] != user_id:
            click.secho(
                "[!] No session found to deallocate the emulator.",
                fg="red"
            )
            return
        
        for key in ["viewer_pid", "local_server_pid"]:
            pid = session.get(key)
            if pid:
                try:
                    if platform.system() == "Windows":
                        subprocess.call(
                            ["taskkill", "/F", "/T", "/PID", str(pid)],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL
                        )
                    else:
                        os.killpg(os.getpgid(pid), signal.SIGKILL)
                except Exception:
                    pass
            
        url = f"{VDS_BASE_URL}/flintlab/api/v1/vd/devices/devices/stop"

        headers = {
                "Authorization": f"Bearer {nat}",
                "Content-Type": "application/json",
                "X-Tenant-Id": tenant_id
            }

        payload = {
            "device_id": device_id
        }

        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=15)
            if resp.status_code in (200, 204):
                click.secho(
                    f"[✓] Emulator {device_id} deallocated successfully.",
                    fg="green"
                )
            elif resp.status_code == 404:
                click.secho(
                    "[i] Invalid instance id, please check your instance id and try deallocating again.",
                    fg="yellow"
                )
            else:
                click.secho(
                    f"[!] Backend deallocation failed (HTTP {resp.status_code}): {resp.text}",
                    fg="red"
                )

        except requests.RequestException as e:
            click.secho(f"[!] Backend unreachable", fg="red")
    else:
        click.secho(f"[!] No active session found for this instance id", fg="red")

    # Final cleanup
    cleanup_session(device_id)
