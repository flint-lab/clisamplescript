"""Setup and ensure Electron dependencies for FlintCLI viewer are installed."""

import os
import platform
import subprocess
import shutil
import sys
from pathlib import Path
import click


def get_viewer_dir():
    """Get the correct viewer directory path whether installed or in development."""
    # Try development path first
    dev_path = os.path.join(os.path.dirname(__file__), "viewer")
    if os.path.exists(dev_path):
        return dev_path
    
    # Try installed package path
    installed_path = os.path.join(sys.prefix, "lib", f"python{sys.version_info.major}.{sys.version_info.minor}", 
                                 "site-packages", "flintcli", "viewer")
    if os.path.exists(installed_path):
        return installed_path
    
    # Fallback to current directory
    return os.path.join(os.path.dirname(__file__), "viewer")

def install_electron_if_needed():
    viewer_dir = get_viewer_dir()
    marker_path = os.path.join(viewer_dir, ".electron_installed")
    electron_path = os.path.join(viewer_dir, "node_modules", "electron")
    package_json = os.path.join(viewer_dir, "package.json")

    if not os.path.exists(package_json):
        print(f"[!] package.json not found in viewer directory at {viewer_dir}. Cannot install Electron.")
        return False

    if os.path.exists(marker_path):
        return True  # Already installed once

    if not os.path.exists(electron_path):
        print("[*] Installing Electron dependencies via npm...")

        # Check if npm is available
        npm_path = shutil.which("npm")
        if not npm_path:
            print("[!] npm not found in PATH. Please ensure Node.js and npm are installed.")
            return False

        try:
            result = subprocess.run(
                ["npm", "install"],
                cwd=viewer_dir,
                shell=(platform.system().lower() == "windows"),
                check=True,
                capture_output=True,
                text=True
            )
            print(result.stdout)
            if result.stderr:
                print("[stderr]", result.stderr)
        except subprocess.CalledProcessError as e:
            print("[!] Electron setup failed during npm install:")
            print(e.stderr or str(e))
            return False

    # Set permissions for chrome-sandbox on Linux
    if platform.system().lower() == "linux":
        sandbox_path = os.path.join(electron_path, "dist", "chrome-sandbox")
        if os.path.exists(sandbox_path):
            print("[i] Setting permissions for chrome-sandbox...")
            try:
                subprocess.run(["sudo", "chown", "root:root", sandbox_path], check=True)
                subprocess.run(["sudo", "chmod", "4755", sandbox_path], check=True)
            except subprocess.CalledProcessError as e:
                print("[!] Failed to set sandbox permissions:", e)
                return False

    # Write install marker
    try:
        with open(marker_path, "w") as f:
            f.write("installed")
        print("[✓] Electron dependencies installed successfully.")
        return True
    except Exception as e:
        print("[!] Failed to write marker file:", e)
        return False
    



