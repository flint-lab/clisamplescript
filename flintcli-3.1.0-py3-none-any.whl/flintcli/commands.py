"""Device management commands for FlintCLI."""

import click
from flintcli.physical_devices import (
    list_physical_devices,
    bind_physical_device,
    stream_physical_device,
    deallocate_physical_device,
)
from flintcli.emulator_devices import (
    list_emulator_devices,
    allocate_emulator,
    stream_emulator,
    deallocate_emulator,
)
from flintcli.utils import require_auth


def _validate_bind_device_type(ctx, param, value):
    """
    Ensure --physical-device and --emulator are mutually exclusive for `bind`.
    Implemented at the option layer so Click returns a non-zero exit code on error.
    """
    if value is None:
        return value

    other_name = "is_emulator" if param.name == "is_physical" else "is_physical"
    other_value = ctx.params.get(other_name)

    if value and other_value:
        raise click.BadParameter("Use only one of --physical-device or --emulator")

    return value


def _validate_duration_minutes(ctx, param, value):
    """Validate --duration_minutes and raise a user-friendly error if out of range."""
    if value is None:
        return value
    min_minutes, max_minutes = 3, 720
    if not (min_minutes <= value <= max_minutes):
        raise click.BadParameter(
            f"Duration must be between {min_minutes} and {max_minutes} minutes "
            f"(you gave {value}). Please choose a value in that range."
        )
    return value

@click.command(
    "list",
    short_help="List devices (physical or emulator recipes).",
    help="""
        List devices.
        
        You must choose exactly one of:
          flintcli list --physical-devices
          flintcli list --emulator
    """,
)
@click.option("--physical-devices", is_flag=True, help="List only physical devices.")
@click.option("--emulator", is_flag=True, help="List only emulator recipes.")
@require_auth
def list(physical_devices, emulator):
    """
    Detailed help:

    --physical-devices   List only physical devices  
    --emulator  List only emulator recipes
    """

    # Prevent both flags together
    if physical_devices and emulator:
        click.echo("Please use only one flag: --physical-devices OR --emulator")
        raise SystemExit(1)

    if not physical_devices and not emulator:
        click.echo("Please specify one flag: --physical-devices OR --emulator")
        raise SystemExit(1)

    if physical_devices:
        list_physical_devices()
    else:
        list_emulator_devices()

@click.command(
    "bind",
    short_help="Allocate a physical device or emulator.",
    help="""
    Allocate a device.

    Physical device:
      flintcli bind --physical-device -i <device_id> --duration_minutes <minutes>

    Emulator:
      flintcli bind --emulator -i <recipe_uuid> --duration_minutes <minutes>

    Notes:
      - The --duration_minutes flag is required for both physical and emulator allocations.
      - Minimum duration is 3 minutes.
      - Maximum duration is 720 minutes.
    """,
)
@click.option(
    "--physical-device",
    "is_physical",
    is_flag=True,
    callback=_validate_bind_device_type,
    help="Bind a physical device.",
)
@click.option(
    "--emulator",
    "is_emulator",
    is_flag=True,
    callback=_validate_bind_device_type,
    help="Allocate an emulator from recipe UUID.",
)
@click.option("-i", "--device-id", required=True, help="Device ID (physical) or recipe UUID (emulator).")
@click.option(
    "--duration_minutes",
    "duration_minutes",
    type=int,
    required=True,
    callback=_validate_duration_minutes,
    help="Duration in minutes to allocate the device (required, minimum 3 and maximum 720).",
)
@click.option("-p", "port", type=int, help="Preferred local port for ADB binding (for both physical devices and emulators).")
@require_auth
def bind_device(is_physical, is_emulator, device_id, duration_minutes, port):
    """
    Bind a physical device or allocate an emulator.
    - Physical: flintcli bind --physical-device -i DEVICE_ID
    - Emulator: flintcli bind --emulator -i RECIPE_UUID
    """
    if not is_physical and not is_emulator:
        click.secho(
            "Error: Please specify one of --physical-device or --emulator",
            fg="red",
        )
        raise SystemExit(1)

    # -------- PHYSICAL DEVICE --------
    if is_physical:
        bind_physical_device(device_id, duration_minutes, port)
        return

    # -------- EMULATOR --------
    if is_emulator:
        click.secho(f"[→] Allocating emulator from recipe {device_id}", fg="yellow")
        allocate_emulator(device_id, duration_minutes, port)


@click.command(
    "stream",
    short_help="Open a live stream for a device.",
    help="""
    Stream a device.

    Physical device:
      flintcli stream --physical-device -i DEVICE_ID
      flintcli stream -i DEVICE_ID

    Emulator:
      flintcli stream --emulator -i INSTANCE_ID
    """,
)
@click.option("-i", "--device-id", required=True, help="Device ID to stream")
@click.option("--physical-device", is_flag=True, help="Stream a physical device.")
@click.option("--emulator", is_flag=True, help="Stream an emulator instance.")
@require_auth
def stream_device(device_id, physical_device, emulator):
    """Use 'flintcli stream --physical-device -i DEVICE_ID' or 'flintcli stream --emulator -i INSTANCE_ID'."""

    if physical_device and emulator:
        click.secho(
            "[x] Please choose only one: --physical-device OR --emulator",
            fg="red",
        )
        raise SystemExit(1)
    if not physical_device and not emulator:
        physical_device = True

    if physical_device:
        stream_physical_device(device_id)
    else:
        stream_emulator(device_id)


@click.command(
    "deallocate",
    short_help="Release a running device.",
    help="""
    Deallocate a device.

    Physical device:
      flintcli deallocate -i DEVICE_ID
      flintcli deallocate --physical-device -i DEVICE_ID

    Emulator:
      flintcli deallocate --emulator -i INSTANCE_ID
    """,
)
@click.option("-i", "--device-id", required=True, help="Device ID to deallocate")
@click.option("--physical-device",is_flag=True,help="Deallocate a physical device")
@click.option("--emulator",is_flag=True,help="Deallocate an emulator instance")
@require_auth
def deallocate_device(device_id, physical_device, emulator):
    """
    Use:
      flintcli deallocate --physical-device -i DEVICE_ID
      flintcli deallocate --emulator -i DEVICE_ID
    """

    # Ensure ONLY one type is selected
    if physical_device and emulator:
        click.secho("[x] Please choose only one: --physical-device OR --emulator", fg="red")
        raise SystemExit(1)
    if not physical_device and not emulator:
        physical_device = True

    if physical_device:
        deallocate_physical_device(device_id)
    else:
        deallocate_emulator(device_id)



