import os, json, signal, platform, subprocess
from flintcli.config import SESSION_DIR

def session_path(device_id):
    return os.path.join(SESSION_DIR, f"{device_id}.json")

def load_session(device_id):
    path = session_path(device_id)
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return json.load(f)

def save_session(device_id, data):
    os.makedirs(SESSION_DIR, exist_ok=True)
    with open(session_path(device_id), "w") as f:
        json.dump(data, f, indent=2)

def cleanup_session(device_id):
    session = load_session(device_id)
    if not session:
        return

    # Kill local stream server
    pid = session.get("local_server_pid")
    if pid:
        try:
            if platform.system() == "Windows":
                subprocess.call(
                    ["taskkill", "/F", "/T", "/PID", str(pid)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            else:
                os.killpg(os.getpgid(pid), signal.SIGKILL)
        except Exception:
            pass

    try:
        os.remove(session_path(device_id))
    except Exception:
        pass