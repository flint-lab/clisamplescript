import requests
import subprocess
import re
import time
import jwt
import os
from pathlib import Path
from flintcli.utils import get_free_port
from flintcli.config import VDS_BASE_URL, get_stored_nat, GMSAAS_API_TOKEN

# Global flag to ensure bootstrap runs only once
_bootstrap_done = False

def get_gmsaas_token() -> str:
    """
    Fetch the GMSAAS authentication token from the backend endpoint.
    This replaces the hardcoded token.
    """
    nat = get_stored_nat()
    decoded = jwt.decode(nat, options={"verify_signature": False}) if nat else {}
    tenant_id = decoded.get("tenant_id", "default")
    user_id = decoded.get("sub", "flintcli-user")
    if not nat:
        raise RuntimeError("No NAT token available. Run `flintcli auth` first.")

    try:
        resp = requests.get(
            f"{VDS_BASE_URL}/flintlab/api/v1/gm/instances/gmsaas-token",
            headers={
                "Authorization": f"Bearer {nat}",
                "x-tenant-id": tenant_id,
                "x-sub": user_id
            },
            timeout=10
        )
        resp.raise_for_status()
        token = resp.text.strip('"')
        if not token:
            raise ValueError("Empty GMSAAS token received from backend")
        return token
    except requests.RequestException as e:
        raise RuntimeError("[!] Failed to connect")
    except ValueError as e:
        raise RuntimeError("[!] Invalid connection details")

def gmsaas_auth():
    try:
        gmsaas_token = get_gmsaas_token()
    except RuntimeError as e:
        raise RuntimeError("[!] Emulator support unavailable")

    
    subprocess.run(
        ["gmsaas", "auth", "token", gmsaas_token],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=True,
    )

def bootstrap_emulator_dependencies():
    """Run once: check gmsaas, authenticate, configure Android SDK."""
    global _bootstrap_done
    if _bootstrap_done:
        return
    _bootstrap_done = True

    # 1. gmsaas must be installed
    try:
        subprocess.run(
            ["gmsaas", "--version"],
            capture_output=True,
            check=True,
            timeout=5
        )
    except Exception:
        raise RuntimeError("Emulator support unavailable: gmsaas not installed")

    # 2. Authenticate with internal token
    gmsaas_auth()

    # 3. Ensure Android SDK path is configured
    try:
        ensure_android_sdk_configured()
    except Exception:
        raise RuntimeError("Emulator support unavailable: Android SDK path not configured")


def adb_connect(device_id: str, port: int | None = None) -> str:
    """
    Bind ADB to a Genymotion instance and return the localhost:port serial.
    Waits up to 60 seconds for the binding to succeed.
    """
    gmsaas_auth()
    
    requested_port = None
    if port is not None:
        requested_port = get_free_port(port)

    cmd = ["gmsaas", "instances", "adbconnect", device_id]
    if requested_port is not None:
        cmd += ["--adb-serial-port", str(requested_port)]

    for attempt in range(10):  # ~40s total
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True,
            )
            output = result.stdout.strip()
            match = re.search(r"localhost:\d+", output)
            if match:
                return match.group(0)
        except subprocess.CalledProcessError:
            pass

        time.sleep(4)

    raise RuntimeError(f"ADB binding failed for device {device_id}")


def ensure_android_sdk_configured():
    """
    Ensure Genymotion SaaS (gmsaas) knows the Android SDK path.
    Auto-detects common locations or reads ANDROID_SDK_ROOT environment variable.
    """

    # 1️⃣ Check if user already set android-sdk-path in gmsaas
    try:
        result = subprocess.run(
            ["gmsaas", "config", "get", "android-sdk-path"],
            capture_output=True, text=True, timeout=5
        )
        existing_path = result.stdout.strip()
        if existing_path and Path(existing_path).exists():
            # print(f"[INFO] gmsaas Android SDK path already set: {existing_path}")
            return
    except Exception:
        pass  # Not set yet

    # 2️⃣ Attempt to detect Android SDK automatically
    possible_paths = [
        os.environ.get("ANDROID_SDK_ROOT"),
        os.environ.get("ANDROID_HOME"),  # legacy variable
        Path.home() / "Android" / "Sdk",  # default user home location
        Path("/usr/lib/android-sdk"),     # common Linux
        Path("/opt/android-sdk"),         # alternative Linux
        Path("C:/Users/") / os.getlogin() / "AppData/Local/Android/Sdk",  # Windows
        Path("C:/Android/Sdk"),           # Windows alt
    ]

    sdk_path = next((str(p) for p in possible_paths if p and Path(p).exists()), None)

    if sdk_path:
        # print(f"Setting Android SDK path for gmsaas: {sdk_path}")
        try:
            subprocess.run(
                ["gmsaas", "config", "set", "android-sdk-path", sdk_path],
                check=True
            )
            # print("Android SDK path configured successfully for gmsaas")
        except Exception as e:
            # print(f"Failed to set Android SDK path automatically: {e}")
            # print("Please set it manually using:")
            # print("  gmsaas config set android-sdk-path <sdk_path>")
            raise 
    else:
        print("Could not detect Android SDK automatically.")
        print("Please install Android SDK and set path using:")
        print("  export ANDROID_SDK_ROOT=<path>   # Linux/macOS")
        print("  setx ANDROID_SDK_ROOT <path>      # Windows")
        print("  or gmsaas config set android-sdk-path <sdk_path>")